#ifdef GITVERSION
const char* gitversion = GITVERSION ;
#else
const char* gitversion;
#endif
